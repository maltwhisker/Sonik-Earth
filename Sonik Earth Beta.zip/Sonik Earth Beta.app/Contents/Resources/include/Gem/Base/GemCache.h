#ifdef __GNUC__
# warning GemCache.h is deprecated - please include "Gem/Cache.h" instead
#endif
#include "Gem/Cache.h"
