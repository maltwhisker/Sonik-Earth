peakit~ - find frequency peaks of an FFT and output lists of frequencies and magnitudes.

(c) Edward Kelly 2005. This software is subject to the GNU General Public License, and may be freely copied, distributed and modified.

You will need the listmoses external to make the best use of this software, and to run the peakit-listmoses demonstration patches in the help file.

Have fun!
Ed Kelly <morph_2016@yahoo.co.uk>
