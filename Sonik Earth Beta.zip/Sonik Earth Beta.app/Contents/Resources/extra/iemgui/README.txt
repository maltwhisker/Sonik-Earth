This library extends the performance of miller puckette's pure data (pd).

iemgui is written by Thomas Musil from IEM Graz Austria
 and it is compatible to miller puckette's pd-0.37-3 to pd-0.39-2.
see also LICENCE.txt, GnuGPL.txt.

iemgui contains some graphical objects.