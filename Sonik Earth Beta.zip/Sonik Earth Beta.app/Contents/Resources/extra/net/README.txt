A collection of network objects for Pure Data.
For more info see http://puredata.org
or
http://sourceforge.net/projects/pure-data/
Bugs and feature requests should be filed at http://sourceforge.net/tracker/?group_id=55736
Send questions to the mailing list at http://lists.puredata.info/listinfo/pd-list

