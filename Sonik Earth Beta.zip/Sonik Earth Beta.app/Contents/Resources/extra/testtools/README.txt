testtools

----------------------------------------------------------------------------------------------------

Abstractions to produce unit test patches for Pd objects. See example patches for howto. Suggestion: use uniform suffix 'unittest' in test patch names.

unit test abstractions: 
unit-test-frame.pd
unit-test-frame~.pd

unit test example patches:
example-unittest.pd
example~-unittest.pd

reference files:
example.wav
example~.wav

Katja Vetter and Fred Jan Kraan November 2011

----------------------------------------------------------------------------------------------------